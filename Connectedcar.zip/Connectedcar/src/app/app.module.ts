import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { ROUTES } from './app.routes';

import { AuthService } from './auth/auth.service';
import { CallbackComponent } from './callback/callback.component';
import { CustomerLookupComponent } from './customer-lookup/customer-lookup.component';
import {  Routes } from '@angular/router';
import { WindowService } from './window.service';
import { ConfirmPINComponent } from './confirm-pin/confirm-pin.component';
import {ValidatePINService} from './validate-pin.service';
import { ConfirmComponent } from './confirm/confirm.component';
import { LoginComponent } from './login/login.component';
const appRoutes: Routes = [
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CallbackComponent,
    CustomerLookupComponent,
    ConfirmPINComponent,
    ConfirmComponent,
    LoginComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot( ROUTES)
   
  ],
  providers: [AuthService,WindowService,CustomerLookupComponent,ConfirmPINComponent,
  ValidatePINService,],
  bootstrap: [AppComponent]
})
export class AppModule { }
