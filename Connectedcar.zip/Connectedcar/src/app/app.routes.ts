import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CallbackComponent } from './callback/callback.component';
import { CustomerLookupComponent } from './customer-lookup/customer-lookup.component';
import { ConfirmPINComponent } from './confirm-pin/confirm-pin.component';
import { ConfirmComponent } from './confirm/confirm.component';
import { LoginComponent} from './login/login.component'
export const ROUTES: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'callback', component: CallbackComponent },
  { path: 'customer', component: CustomerLookupComponent },
  { path: 'confrmationdone', component: ConfirmComponent }, 
  { path: 'confirmPIN', component: ConfirmPINComponent },
 { path: 'login', component: LoginComponent },

  { path: '**', redirectTo: '' }
];
