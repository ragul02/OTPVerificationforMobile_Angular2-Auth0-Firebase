import { Component, OnInit,Input ,Injectable} from '@angular/core';
import * as firebase from 'firebase';
import { WindowService } from '../window.service';
import { AuthService } from './../auth/auth.service';
import { Router } from '@angular/router';
import { ConfirmPINComponent } from '../confirm-pin/confirm-pin.component';
import {ValidatePINService} from '../validate-pin.service';



/////////FirebaseConfig variable
  var config = {
    apiKey: "AIzaSyBlwjCXPq24ZB79tTfXaC8CgSIdVDUPa_Y",
    authDomain: "connectedcar-fbb30.firebaseapp.com",
    databaseURL: "https://connectedcar-fbb30.firebaseio.com",
    projectId: "connectedcar-fbb30",
    storageBucket: "connectedcar-fbb30.appspot.com",
    messagingSenderId: "151171866437"
  };
  firebase.initializeApp(config);

@Component({
  selector: 'app-customer-lookup',
  templateUrl: './customer-lookup.component.html',
  styleUrls: ['./customer-lookup.component.css']
})

export class CustomerLookupComponent implements OnInit {

  windowRef: any;
  verificationCode: string;
  user: any;
 @Input() appVerifier:any;

  public recaptchaVerifier:firebase.auth.RecaptchaVerifier;
 constructor(private win: WindowService,public auth:AuthService,private router:Router,public confirmpin:ConfirmPINComponent,
public valipdatePIN: ValidatePINService) { }
  ngOnInit() {
    console.log('loaded init in CustomerLookupComponent');
    /////////Loads Captcha verifier///////////
     this.windowRef = this.win.windowRef
    this.windowRef.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container');
    this.windowRef.recaptchaVerifier.render() 
  this.appVerifier = this.windowRef.recaptchaVerifier;

  }

sendPIN(){  
  const phoneNumberString = "+91" + this.auth.phonenumber;  //////Replace '+91' with your country code//////
console.log('inside customer lookup',phoneNumberString);
  firebase.auth().signInWithPhoneNumber(phoneNumberString, this.appVerifier)
    .then( confirmationResult => {
      console.log('sent',confirmationResult);  
       this.windowRef.confirmationResult =confirmationResult; 
       this.router.navigateByUrl('/confirmPIN'); 
      // SMS sent. Prompt user to type the code from the message, then sign the
      // user in with confirmationResult.confirm(code).
  })  
    .catch(function (error) {
    console.error("SMS not sent", error);
  });

}

verifyLoginCode() {
    this.windowRef.confirmationResult
                  .confirm(this.verificationCode)
                  .then( result => {
                    this.user = result.user;
                    console.log('ver code',this.verificationCode);
                    console.log('User SignIN successfully');
    })
    .catch( error => console.log(error, "Incorrect code entered?"));
  }

}
