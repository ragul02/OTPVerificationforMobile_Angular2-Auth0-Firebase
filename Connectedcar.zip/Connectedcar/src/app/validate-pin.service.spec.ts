import { TestBed, inject } from '@angular/core/testing';

import { ValidatePINService } from './validate-pin.service';

describe('ValidatePINService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ValidatePINService]
    });
  });

  it('should be created', inject([ValidatePINService], (service: ValidatePINService) => {
    expect(service).toBeTruthy();
  }));
});
