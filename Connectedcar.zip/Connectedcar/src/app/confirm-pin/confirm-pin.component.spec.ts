import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmPINComponent } from './confirm-pin.component';

describe('ConfirmPINComponent', () => {
  let component: ConfirmPINComponent;
  let fixture: ComponentFixture<ConfirmPINComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmPINComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmPINComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
