import { Component, OnInit, Input, ViewChild } from '@angular/core';
import * as firebase from 'firebase';
import { Router } from '@angular/router';
import { CustomerLookupComponent } from '../customer-lookup/customer-lookup.component';
import { WindowService } from '../window.service';

@Component({
  selector: 'app-confirm-pin',
  templateUrl: './confirm-pin.component.html',
  styleUrls: ['./confirm-pin.component.css']
})


export class ConfirmPINComponent implements OnInit {

  windowRef: any;
  appVerifier: any;
  verificationCode: string;
  user: any;
  constructor(private win: WindowService, private router: Router) { }

  ngOnInit() {
    this.windowRef = this.win.windowRef;
  }


  verifyLoginCode() {
    /////////////OTP Verification/////////////////
    this.windowRef.confirmationResult
      .confirm(this.verificationCode)
      .then(result => {
        this.user = result.user;
        console.log('ver code', this.verificationCode);
        console.log('User SignIN successfully');
        this.router.navigateByUrl('/confrmationdone');
      })
      .catch(error => {
        window.alert('Incorrect code entered');
        console.log(error, "Incorrect code entered?");
      });
  }
}
