import { Injectable,OnInit } from '@angular/core';
import { AUTH_CONFIG } from './auth0-variables';
import { Router } from '@angular/router';
import * as auth0 from 'auth0-js';
import { Component, Input } from '@angular/core';


@Injectable()
export class AuthService implements OnInit{
ngOnInit() {}

  auth0 = new auth0.WebAuth({
    clientID: AUTH_CONFIG.clientID,
    domain: AUTH_CONFIG.domain,
    responseType: 'token id_token',
    audience: `https://${AUTH_CONFIG.domain}/userinfo`,
    redirectUri: AUTH_CONFIG.callbackURL,
    scope: 'openid'
  });

  @Input() phonenumber :any;

  constructor(public router: Router) {}

  public login(): void {
    console.log('inside service login');
  this.auth0.authorize();
  }

  public handleAuthentication(): void {
    // this.auth0.authorize();
    this.auth0.parseHash((err, authResult) => {
    console.log('inside service handleAuthentication');      
      if (authResult && authResult.accessToken && authResult.idToken) {
        console.log('authenticated');
        this.setSession(authResult);
        this.router.navigate(['/home']);
      } else if (err) {
        console.log('not authenticated');
       this.router.navigate(['/home']);
        console.log(err);
        alert(`Error: ${err.error}. Check the console for further details.`);
      }
    });
  }

  private setSession(authResult): void {
    // Set the time that the access token will expire at
    const expiresAt = JSON.stringify((authResult.expiresIn * 1000) + new Date().getTime());
    localStorage.setItem('access_token', authResult.accessToken);
    localStorage.setItem('id_token', authResult.idToken);
    localStorage.setItem('expires_at', expiresAt);
  }

  public logout(): void {
    // Remove tokens and expiry time from localStorage
    localStorage.removeItem('access_token');
    localStorage.removeItem('id_token');
    localStorage.removeItem('expires_at');
    // Go back to the home route
    this.router.navigate(['/']);
  }

  public isAuthenticated(): boolean {
    // Check whether the current time is past the
    // access token's expiry time
    const expiresAt = JSON.parse(localStorage.getItem('expires_at'));
    return new Date().getTime() < expiresAt;
  }

// ionViewDidLoad() {
//   this.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container');
// }
public getPhoneNumber(phone_no){
  // var getPhonenumber='';
 console.log(phone_no.value);
 this.phonenumber =phone_no.value;
return this.phonenumber;
}
}
