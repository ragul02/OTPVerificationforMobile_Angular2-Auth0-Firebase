interface AuthConfig {
  clientID: string;
  domain: string;
  callbackURL: string;
}

export const AUTH_CONFIG: AuthConfig = {
  clientID: 'rJhyVR19zQm2tHEJ9c-QY91y46-ofQ68',
  domain: 'ragul.auth0.com',
  callbackURL: 'http://localhost:3000/callback'
};
