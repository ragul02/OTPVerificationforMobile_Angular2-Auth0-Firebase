import { Injectable ,OnInit} from '@angular/core';
import { AuthService } from './auth/auth.service';
import { WindowService } from './window.service';
import { Router } from '@angular/router';
import { CustomerLookupComponent } from './customer-lookup/customer-lookup.component';

 var config = {
    apiKey: "AIzaSyBlwjCXPq24ZB79tTfXaC8CgSIdVDUPa_Y",
    authDomain: "connectedcar-fbb30.firebaseapp.com",
    databaseURL: "https://connectedcar-fbb30.firebaseio.com",
    projectId: "connectedcar-fbb30",
    storageBucket: "connectedcar-fbb30.appspot.com",
    messagingSenderId: "151171866437"
  };
  firebase.initializeApp(config);
@Injectable()
export class ValidatePINService implements OnInit{

windowRef: any;
  verificationCode: string;
  user: any;
 
 appVerifier:any;
  public recaptchaVerifier:firebase.auth.RecaptchaVerifier;
 constructor(private win: WindowService,public auth:AuthService,private router:Router) { }



  ngOnInit() {
   console.log('loaded init in service');
    // this.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container');
      //  this.windowRef = this.win.windowRef
    this.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container');
    this.recaptchaVerifier.render() 
  this.appVerifier = this.recaptchaVerifier;
  }
  
 sendPIN(){ 
  
  const phoneNumberString = "+91" + this.auth.phonenumber;
console.log('inside customer lookup in service',phoneNumberString);
  firebase.auth().signInWithPhoneNumber(phoneNumberString, this.appVerifier)
    .then( confirmationResult => {

      console.log('sent',confirmationResult);      
           
           this.router.navigateByUrl('/confirmPIN');
     confirmationResult.confirm('ss').then(function (result) {
  // User signed in successfully.
  console.log('user signed in sucessfully');
  var user = result.user; 
  // ...
}).catch(function (error) {
  // User couldn't sign in (bad verification code?)
  // ...
});  
      // SMS sent. Prompt user to type the code from the message, then sign the
      // user in with confirmationResult.confirm(code).
  })
  
  .catch(function (error) {
    console.error("SMS not sent", error);
  });

}


}
